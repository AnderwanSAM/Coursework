package projetCSI2510_300209487;

/*Andie Erwan Kiswendsida SAMADOULOUGOU 
 * 300209487*/
public class Employeur {

	Employeur(int position , String nom)
	{
		index = position ;
		name = nom ;
	}
	
	int index ; String name;
}
