
/*
 * Nom : Andie SAMADOULOUGOU
 * NE : 300209487
 * */
public class Item {

	 String name ;
	 double value;
	 int  weight;
	
	Item(String name1, double value1, int weight1) 
	{
		this.name = name1 ;
		value =value1;
		weight = weight1;
	}
	
	public String getName() 
	{
		return name;
	}
	public  double  getValue() 
	{
		return value;
	}
	public  int getWeight() 
	{
		return weight;
	}
	
	
}
